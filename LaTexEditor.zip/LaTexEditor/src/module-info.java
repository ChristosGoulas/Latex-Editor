module laTexEditor {
	requires java.desktop;
}